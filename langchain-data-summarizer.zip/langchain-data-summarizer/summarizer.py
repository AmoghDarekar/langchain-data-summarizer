import pandas as pd
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

def summarize_big_data(df: pd.DataFrame, sample_size: int = 10000) -> str:
    # Sample the dataset for performance (adjustable)
    df_sampled = df.sample(n=min(len(df), sample_size), random_state=42)

    # Prepare summary statistics
    numeric_summary = df_sampled.describe().round(2).to_markdown()

    # Handle missing or unexpected columns gracefully
    if 'passenger_count' in df_sampled.columns:
        value_counts = df_sampled['passenger_count'].value_counts().to_string()
    else:
        value_counts = "passenger_count column not found."

    # Create prompt template
    template = """
You are a senior data analyst. Review the dataset statistics and summarize key findings.

Data Summary:
{numeric_summary}

Passenger Count Breakdown:
{value_counts}

Provide:
- High-level numeric trends
- Patterns in passenger distribution
- Interesting anomalies or outliers
"""
    prompt = PromptTemplate(
        input_variables=["numeric_summary", "value_counts"],
        template=template.strip()
    )

    llm = OpenAI(temperature=0.3)
    chain = LLMChain(llm=llm, prompt=prompt)

    return chain.run(numeric_summary=numeric_summary, value_counts=value_counts)
